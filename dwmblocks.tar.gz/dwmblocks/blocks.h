//Modify this file to change what commands output to your statusbar, and recompile using the make command.
static const Block blocks[] = {
	/*Icon*/	/*Command*/		/*Update Interval*/	/*Update Signal*/
	{" ", "free -h | awk '/^Mem/ { print $3\"/\"$2 }' | sed s/i//g",	30,		0},
    {" ", "~/.config/barscripts/temperature/temperature", 2,  0},
    {"", " ~/.config/barscripts/rofi-calendar/rofi-calendar", 5,    0},
	{" ", "date '+%I:%M'",                        2,    0},
	{" ",  "awk -F'[][]' '/Left:/ { print $2 }' <(amixer sget Master)",    2,		0},
};

//sets delimeter between status commands. NULL character ('\0') means no delimeter.
static char delim[] = " | ";
static unsigned int delimLen = 5;
